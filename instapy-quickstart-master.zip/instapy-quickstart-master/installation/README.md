> **Please Note**: The scripts for Linux and RaspberryPi still have to be added!

### Installation

Installing InstaPy is really simple. Just choose the folder of the system you are using and double click the installation file.   
A small Terminal will open up and check if everything necessary is installed.   
Once that is done you will see it downloading and installing InstaPy. 

> If you don't see any error messages, InstaPy is successfully installed. Otherwise, please search the [issues](https://github.com/timgrossmann/InstaPy/issues) for your error, there most likely already will be a solution to that.


---

### Updating InstaPy

In order to update InstaPy you simply choose the folder of the system you are using and then double click the update file.
